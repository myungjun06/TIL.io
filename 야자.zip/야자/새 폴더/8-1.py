number = [1,2,3,4,5,6,7,8,9,10]

print(number[1:3])
print(number[3:])
print(number[:3])
print(number[1:3:2])
print(number[::-1])