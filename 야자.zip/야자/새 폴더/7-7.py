msg = 'seomyungjun'
for ch in msg :
    print(f'{ch}/', end='')