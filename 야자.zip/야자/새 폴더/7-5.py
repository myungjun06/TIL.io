pwd = input('비밀번호?')

while pwd != '#1234' :
    pwd = input('비밀번호?')

print('어서오세요, 문이 열렸습니다!')