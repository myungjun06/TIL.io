list1 = [11, 22, 33, 44, 55]
list2 = ['단출하게', '단아하게', '당당하게']
list3 = []
print(list1)
print(list2)
print(list3)