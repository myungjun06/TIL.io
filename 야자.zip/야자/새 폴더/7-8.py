for i in range(0, 10, 1) :
    print(i, end=' ')

print()

for i in range(0, 10) :
    print(i, end=' ')
print()

for i in range(10) :
    print(i, end=' ')
print()