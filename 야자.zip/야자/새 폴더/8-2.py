size = float(input('손가락 둘레 입력 :'))

if (51.0 < size ) and (55.0 >= size) :
    if (51.0 < size ) and (52.0 >= size) :
        print('9호 추천')
    else :
        if (52.0 < size) and (53.0 >= size) :
            print('10호 추천')
        else :
            if 53.0 < size and 54.0 >= size :
                print('11호 추천')
            else :
                print('12호 추천')
else :
    print('반지 제작이 불가합니다.')