n1 = int(input('첫 번쨰 정수는?'))
n2 = int(input('두 번쨰 정수는?'))

if n1 > n2 : print(f'{n1}은(는) {n2}보다 크다')

if n1 > n2 : 
    print(f'{n1}은(는) {n2} 보다 크다')

if n1 > n2 :
    print(f'{n1}은(는) {n2} 보다 크다', end='')
    print('크다')

print('끝')