cnt = 1
print(cnt)

cnt += 1
print(cnt)

cnt += 1
print(cnt)

cnt += 1
print(cnt)

cnt += 1
print(cnt)